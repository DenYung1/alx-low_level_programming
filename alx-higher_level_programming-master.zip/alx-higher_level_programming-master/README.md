
0x00. Python - Hello, World

