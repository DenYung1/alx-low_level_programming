#!/usr/bin/python3
for num in range(0, 99):
    print('{} = 0x{:x}'.format(num, num))
