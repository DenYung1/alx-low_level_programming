#!/usr/bin/python3
def add(a, b):
    """Return the addition of a and b."""
    return (a + b)
