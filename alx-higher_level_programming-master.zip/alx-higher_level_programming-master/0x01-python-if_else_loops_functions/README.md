0x01. Python - if/else, loops, functions
