0x17. C - Doubly linked lists
