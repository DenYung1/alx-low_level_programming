#!/usr/bin/python3
print("\"Programming is like building a multilingual puzzle")
